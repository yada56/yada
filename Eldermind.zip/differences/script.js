const left = document.getElementById("leftCanvas").getContext("2d");
const right = document.getElementById("rightCanvas").getContext("2d");
let differences = [];
let found = 0;

function drawBase(ctx) {
  ctx.fillStyle = "lightblue";
  ctx.fillRect(0,0,300,300);
  ctx.fillStyle = "green";
  ctx.fillRect(50,200,200,50);
  ctx.fillStyle = "yellow";
  ctx.beginPath();
  ctx.arc(150,80,40,0,Math.PI*2);
  ctx.fill();
}

function randomDifferences() {
  let diffs = [];
  for (let i=0;i<3;i++) {
    diffs.push({
      x: Math.floor(Math.random()*250)+20,
      y: Math.floor(Math.random()*250)+20,
      r: 15
    });
  }
  return diffs;
}

function drawDifferences(ctx, diffs) {
  ctx.fillStyle = "red";
  diffs.forEach(d => {
    ctx.beginPath();
    ctx.arc(d.x,d.y,d.r,0,Math.PI*2);
    ctx.fill();
  });
}

function init() {
  drawBase(left);
  drawBase(right);
  differences = randomDifferences();
  drawDifferences(left, differences); // ซ่อนเฉพาะฝั่งซ้าย
}

document.getElementById("rightCanvas").addEventListener("click", e => {
  const rect = e.target.getBoundingClientRect();
  const x = e.clientX - rect.left;
  const y = e.clientY - rect.top;
  differences.forEach(d => {
    if (!d.found && Math.hypot(d.x-x, d.y-y)<d.r) {
      d.found = true;
      found++;
      right.beginPath();
      right.arc(d.x,d.y,d.r,0,Math.PI*2);
      right.strokeStyle="red";
      right.lineWidth=3;
      right.stroke();
      document.getElementById("status").innerText = `เจอแล้ว ${found}/${differences.length}`;
      if(found===differences.length) {
        document.getElementById("status").innerText = "🎉 ชนะแล้ว!";
      }
    }
  });
});

init();
