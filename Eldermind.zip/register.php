<?php
$host = "localhost";             // Host ของฐานข้อมูล (ถ้าใช้ DirectAdmin/lnw จะเป็น localhost)
$dbname = "eldermindg_test";     // ชื่อฐานข้อมูลของคุณ
$user = "eldermindg_test";       // ชื่อผู้ใช้ฐานข้อมูลของคุณ
$pass = "View2546";       // รหัสผ่านของฐานข้อมูลของคุณ

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e){
    die("เชื่อมต่อ Database ไม่ได้: " . $e->getMessage());
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];

    if (!$username || !$email || !$password || $password !== $password_confirm) {
        $error = "กรอกข้อมูลไม่ถูกต้องหรือรหัสผ่านไม่ตรงกัน";
    } else {
        // ตรวจสอบซ้ำ
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username=? OR email=?");
        $stmt->execute([$username, $email]);
        if ($stmt->fetch()) {
            $error = "ชื่อผู้ใช้หรืออีเมลนี้มีอยู่แล้ว";
        } else {
            // บันทึกลง DB แบบ plaintext
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password_plain) VALUES (?, ?, ?)");
            $stmt->execute([$username, $email, $password]);
            
            // สมัครสมาชิกสำเร็จ → redirect ไปหน้า login.php
            header("Location: login.php");
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ELDERMIND - สมัครสมาชิก</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f7e8e8;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            color: #335964;
        }
        .register-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 350px;
        }
        .main-title {
            font-family: 'Georgia', serif;
            font-size: 2.5em;
            font-weight: bold;
            color: #d14949;
            text-shadow: 
                -1px -1px 0 #335964,  
                1px -1px 0 #335964,
                -1px 1px 0 #335964,
                1px 1px 0 #335964;
            margin-bottom: 20px;
        }
        .input-group {
            margin-bottom: 20px;
            text-align: left;
        }
        .input-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
        }
        .input-group input {
            width: 100%;
            padding: 10px;
            border: 2px solid #335964;
            border-radius: 5px;
            box-sizing: border-box;
            transition: border-color 0.3s;
        }
        .input-group input:focus {
            border-color: #d14949;
            outline: none;
        }
        .register-button {
            width: 100%;
            padding: 12px;
            font-size: 1.1em;
            font-weight: bold;
            color: white;
            background-color: #335964;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .register-button:hover {
            background-color: #2a4751;
        }
        #register-error {
            color: #d14949;
            margin-top: 15px;
            display: <?php echo $error ? 'block' : 'none'; ?>;
            font-weight: 600;
        }
        .additional-links {
            margin-top: 20px;
        }
        .additional-links a {
            color: #335964;
            text-decoration: none;
            font-size: 0.9em;
            margin: 0 10px;
            transition: color 0.3s;
        }
        .additional-links a:hover {
            color: #d14949;
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="register-container">
    <h1 class="main-title">ELDERMIND</h1>
    <p>สร้างบัญชีผู้ใช้ใหม่</p>
    <p id="register-error"><?php echo $error; ?></p>
    <form method="post" action="">
        <div class="input-group">
            <label for="username">ชื่อผู้ใช้</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div class="input-group">
            <label for="email">อีเมล</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="input-group">
            <label for="password">รหัสผ่าน</label>
            <input type="password" id="password" name="password" required>
        </div>
        <div class="input-group">
            <label for="password_confirm">ยืนยันรหัสผ่าน</label>
            <input type="password" id="password_confirm" name="password_confirm" required>
        </div>
        <button type="submit" class="register-button">สมัครสมาชิก</button>
    </form>
    <div class="additional-links">
        <a href="login.php">กลับไปเข้าสู่ระบบ</a>
    </div>
</div>

</body>
</html>
