<?php
// reset_password.php
$host = "localhost";
$dbname = "eldermindg_test";
$user = "eldermindg_test";
$pass = "View2546";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $dbuser, $dbpass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e){
    die("เชื่อมต่อ DB ไม่ได้: " . $e->getMessage());
}

$token = isset($_GET['token']) ? $_GET['token'] : '';
$error = '';
$success = '';

if (!$token) {
    die("ลิงก์ไม่ถูกต้อง");
}

// หา token ใน DB
$stmt = $pdo->prepare("SELECT * FROM password_reset_tokens WHERE token = ? AND used = 0");
$stmt->execute([$token]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    die("ลิงก์ไม่ถูกต้องหรือถูกใช้แล้ว");
}

// ตรวจสอบหมดอายุ
if (new DateTime($row['expires_at']) < new DateTime()) {
    die("ลิงก์หมดอายุ");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    if (!$password || $password !== $password_confirm) {
        $error = "รหัสผ่านไม่ตรงกันหรือไม่ถูกต้อง";
    } else {
        // อัปเดตรหัสผ่านในตาราง users
        $user_id = $row['user_id'];

        // **ถ้าคุณต้องการเก็บ plaintext ตามที่ขอ ให้ใช้บรรทัดนี้**
        $update = $pdo->prepare("UPDATE users SET password_plain = ? WHERE id = ?");
        $update->execute([$password, $user_id]);

        // ---- หากต้องการใช้ password_hash ให้ใช้โค้ดนี้แทน (ปลอดภัยกว่า) ----
        // $password_hash = password_hash($password, PASSWORD_DEFAULT);
        // $update = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
        // $update->execute([$password_hash, $user_id]);
        // ------------------------------------------------------------------------

        // ทำเครื่องหมาย token ว่าใช้แล้ว
        $mark = $pdo->prepare("UPDATE password_reset_tokens SET used = 1 WHERE id = ?");
        $mark->execute([$row['id']]);

        $success = "รีเซ็ตรหัสผ่านสำเร็จ คุณสามารถไปล็อกอินได้";
    }
}
?>
<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8">
<title>รีเซ็ตรหัสผ่าน - ELDERMIND</title>
<style>
body{font-family:Arial;background:#f7e8e8;display:flex;justify-content:center;align-items:center;height:100vh;margin:0}
.box{background:#fff;padding:30px;border-radius:10px;box-shadow:0 4px 12px rgba(0,0,0,.08);width:360px;text-align:left}
h2{color:#d14949;font-family:Georgia;margin-top:0;text-align:center}
input[type=password]{width:100%;padding:10px;border:2px solid #335964;border-radius:6px}
button{width:100%;padding:12px;background:#335964;color:#fff;border:none;border-radius:6px;cursor:pointer}
.message{margin:12px 0;color:#335964;font-weight:600}
.error{color:#d14949;font-weight:700}
.success{color:green;font-weight:700}
</style>
</head>
<body>
<div class="box">
    <h2>ตั้งรหัสผ่านใหม่</h2>

    <?php if($error): ?><div class="message error"><?php echo $error; ?></div><?php endif; ?>
    <?php if($success): ?><div class="message success"><?php echo $success; ?></div><?php endif; ?>

    <?php if(!$success): ?>
    <form method="post" action="">
        <label>รหัสผ่านใหม่</label>
        <input type="password" name="password" required>
        <div style="height:10px"></div>
        <label>ยืนยันรหัสผ่าน</label>
        <input type="password" name="password_confirm" required>
        <div style="height:12px"></div>
        <button type="submit">บันทึกรหัสผ่านใหม่</button>
    </form>
    <?php else: ?>
        <p style="text-align:center"><a href="login.php">ไปที่หน้าล็อกอิน</a></p>
    <?php endif; ?>
</div>
</body>
</html>
