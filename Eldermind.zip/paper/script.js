let symbols = ["🍎","🍎","🍌","🍌","🍇","🍇","🍒","🍒"];
let grid = document.getElementById("grid");
let first = null, lock = false, found = 0;
let rounds = 0;
let timeLeft = 120;
let timerInterval = null;
let gameCount = 0;

// popup elements
let popup = document.getElementById("popup");
let popupRounds = document.getElementById("popup-rounds");
let popupOk = document.getElementById("popup-ok");

function shuffle(a) {
  for (let i = a.length - 1; i > 0; i--) {
    let j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
}

function init() {
  shuffle(symbols);
  grid.innerHTML = "";
  found = 0;
  rounds = 0;
  first = null;
  lock = false;
  document.getElementById("rounds").innerText = rounds;
  document.getElementById("status").innerText = "";

  // เพิ่มจำนวนเกมที่เล่น
  gameCount++;
  document.getElementById("games").innerText = gameCount;

  // Reset Timer
  clearInterval(timerInterval);
  timeLeft = 120;
  document.getElementById("timer").innerText = timeLeft;
  timerInterval = setInterval(updateTimer, 1000);

  symbols.forEach(symbol => {
    let card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <div class="card-inner">
        <div class="card-front">${symbol}</div>
        <div class="card-back">❓</div>
      </div>
    `;
    card.dataset.symbol = symbol;
    card.addEventListener("click", () => flip(card));
    grid.appendChild(card);
  });
}

function flip(card) {
  if (lock || card.classList.contains("flipped")) return;

  card.classList.add("flipped");

  if (!first) {
    first = card;
  } else {
    rounds++;
    document.getElementById("rounds").innerText = rounds;

    if (first.dataset.symbol === card.dataset.symbol) {
      found += 2;
      first = null;
      if (found === symbols.length) {
        endGame("🎉 ชนะแล้ว!");
      }
    } else {
      lock = true;
      setTimeout(() => {
        first.classList.remove("flipped");
        card.classList.remove("flipped");
        first = null;
        lock = false;
      }, 1000);
    }
  }
}

function updateTimer() {
  timeLeft--;
  document.getElementById("timer").innerText = timeLeft;

  if (timeLeft <= 0) {
    loseGame(); // 🆕 ใช้ popup
  }
}

// ฟังก์ชันจบเกมแบบชนะ
function endGame(message) {
  clearInterval(timerInterval);
  document.getElementById("status").innerText = message;
  lock = true;

  setTimeout(() => {
    init();
  }, 5000);
}

// 🆕 ฟังก์ชันแพ้ (หมดเวลา)
function loseGame() {
  clearInterval(timerInterval);
  lock = true;
  popupRounds.innerText = rounds;
  popup.style.display = "flex";
}

// ปุ่ม popup "ตกลง"
popupOk.addEventListener("click", () => {
  popup.style.display = "none";
  gameCount = 0; // รีเซ็ตจำนวนเกม
  document.getElementById("games").innerText = gameCount;
  init(); // เริ่มเกมใหม่
});

document.getElementById("restart").addEventListener("click", init);

init();
