<?php
session_start();

// ตรวจสอบว่าผู้ใช้ล็อกอินหรือไม่
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$username = $_SESSION['username'];

// ตั้งค่า DB ของ LNW Hosting
$host = "localhost";  // host จริง
$dbname = "eldermindg_test";          // ชื่อฐานข้อมูล
$dbuser = "eldermindg_test";          // ชื่อผู้ใช้ฐานข้อมูล
$dbpass = "View2546";                 // รหัสผ่านฐานข้อมูล

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $dbuser, $dbpass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // ดึงประวัติการเล่นเกมจากตาราง game_scores
    $stmt = $pdo->prepare("SELECT game_id, score FROM game_scores WHERE user_id = ? ORDER BY id DESC");
    $stmt->execute([$username]);
    $history = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch(PDOException $e){
    die("เชื่อมต่อ DB ไม่ได้: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<title>ข้อมูลของคุณ</title>
<style>
body { margin: 0; font-family: "Prompt", sans-serif; background-color: #fcdede; display: flex; height: 100vh; }
.sidebar { width: 120px; background-color: #0a4747; display: flex; flex-direction: column; align-items: center; justify-content: flex-start; padding-top: 20px; }
.sidebar .icon { width: 60px; height: 60px; border-radius: 50%; background-color: #fcdede; display: flex; align-items: center; justify-content: center; margin-top: 20px; }
.sidebar .icon::before { content: "👤"; font-size: 32px; }
.content { flex: 1; padding: 40px; }
h1 { font-size: 28px; color: #0a4747; margin-bottom: 20px; text-decoration: underline; }
.profile { display: flex; align-items: center; gap: 30px; margin-bottom: 30px; }
.profile .avatar { width: 120px; height: 120px; border-radius: 50%; background-color: #e74c3c; display: flex; align-items: center; justify-content: center; color: #fcdede; font-size: 48px; }
.profile .info { font-size: 20px; color: #0a4747; }
.profile .info .name { font-size: 24px; margin-bottom: 8px; border-bottom: 2px solid #e74c3c; display: inline-block; }
.history { background-color: #0a4747; color: #e74c3c; padding: 20px; border-radius: 10px; font-size: 20px; font-weight: bold; height: 200px; overflow-y: auto; }
.history::-webkit-scrollbar { width: 8px; }
.history::-webkit-scrollbar-thumb { background-color: #e74c3c; border-radius: 4px; }
.history::-webkit-scrollbar-track { background-color: #fcdede; }
.logout-button { margin-top: 20px; padding: 10px 20px; background-color: #335964; color: #fff; border: none; border-radius: 5px; cursor: pointer; font-weight: bold; transition: background-color 0.3s; }
.logout-button:hover { background-color: #2a4751; }
</style>
</head>
<body>
<div class="sidebar">
  <div class="icon"></div>
</div>

<div class="content">
  <h1>ข้อมูลของคุณ</h1>
  <div class="profile">
    <div class="avatar">👤</div>
    <div class="info">
      <div class="name"><?php echo htmlspecialchars($username); ?></div>
      <div>ข้อมูลอื่น ๆ</div>
    </div>
  </div>

  <div class="history">
    <p>ประวัติการเล่นเกม + โชว์คะแนน</p>
    <?php
    if (!empty($history)) {
        foreach ($history as $row) {
            echo "<p>- " . htmlspecialchars($row['game_name']) . " : " . htmlspecialchars($row['score']) . " คะแนน</p>";
        }
    } else {
        echo "<p>ยังไม่มีประวัติการเล่นเกม</p>";
    }
    ?>
  </div>

  <form method="post" action="login.php">
    <button type="submit" class="logout-button">ออกจากระบบ</button>
  </form>
</div>
</body>
</html>
