<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<title>เกมเขาวงกต</title>
<style>
  body {
    font-family: 'Kanit', sans-serif;
    text-align: center;
    background: #E8F5E9; /* เขียวมิ้นท์อ่อน */
    margin: 0;
    padding: 0;
  }
  h1 {
    font-size: 2.2rem;
    margin: 20px 0;
    color: #2E7D32;
  }
  canvas {
    border: 3px solid #388E3C;
    margin-top: 10px;
    background: #FFFDE7; /* พื้นทางเดินสีครีม */
  }
  #msg {
    font-size: 1.8rem;
    margin-top: 15px;
    font-weight: bold;
    color: #1565C0;
  }
</style>
</head>
<body>
  <h1>🌀 เกมเขาวงกต</h1>
  <canvas id="maze" width="300" height="300"></canvas>
  <div id="msg"></div>

<script>
const canvas = document.getElementById("maze");
const ctx = canvas.getContext("2d");
let maze=[], size=10, player={x:0,y:0};

function genMaze() {
  maze=[];
  for(let y=0;y<size;y++) {
    let row=[];
    for(let x=0;x<size;x++) {
      row.push(Math.random()<0.25 ? 1:0); // 25% เป็นกำแพง
    }
    maze.push(row);
  }
  maze[0][0]=0; // เริ่ม
  maze[size-1][size-1]=0; // เป้าหมาย
}

function drawMaze() {
  ctx.clearRect(0,0,300,300);
  for(let y=0;y<size;y++) {
    for(let x=0;x<size;x++) {
      ctx.fillStyle = maze[y][x] ? "#90A4AE" : "#FFFDE7"; // กำแพงเทาอ่อน / ทางเดินครีม
      ctx.fillRect(x*30,y*30,30,30);
    }
  }
  ctx.fillStyle="#42A5F5"; // ผู้เล่นฟ้าใส
  ctx.fillRect(player.x*30,player.y*30,30,30);
  ctx.fillStyle="#66BB6A"; // เป้าหมายเขียวมิ้นท์
  ctx.fillRect((size-1)*30,(size-1)*30,30,30);
}

document.addEventListener("keydown", e=>{
  let nx=player.x, ny=player.y;
  if(e.key==="ArrowUp") ny--;
  if(e.key==="ArrowDown") ny++;
  if(e.key==="ArrowLeft") nx--;
  if(e.key==="ArrowRight") nx++;
  if(nx>=0 && ny>=0 && nx<size && ny<size && maze[ny][nx]===0) {
    player.x=nx; player.y=ny;
    if(nx===size-1 && ny===size-1) {
      document.getElementById("msg").innerText="🎉 เก่งมาก! ออกมาได้แล้ว!";
    }
  }
  drawMaze();
});

function init() {
  genMaze();
  player={x:0,y:0};
  drawMaze();
}
init();
</script>
</body>
</html>

const canvas = document.getElementById("maze");
const ctx = canvas.getContext("2d");
let maze=[], size=10, player={x:0,y:0};

function genMaze() {
  maze=[];
  for(let y=0;y<size;y++) {
    let row=[];
    for(let x=0;x<size;x++) {
      row.push(Math.random()<0.25 ? 1:0); // 25% เป็นกำแพง
    }
    maze.push(row);
  }
  maze[0][0]=0; // เริ่ม
  maze[size-1][size-1]=0; // เป้าหมาย
}

function drawMaze() {
  ctx.clearRect(0,0,300,300);
  for(let y=0;y<size;y++) {
    for(let x=0;x<size;x++) {
      ctx.fillStyle = maze[y][x]?"black":"white";
      ctx.fillRect(x*30,y*30,30,30);
    }
  }
  ctx.fillStyle="blue";
  ctx.fillRect(player.x*30,player.y*30,30,30);
  ctx.fillStyle="green";
  ctx.fillRect((size-1)*30,(size-1)*30,30,30);
}

document.addEventListener("keydown", e=>{
  let nx=player.x, ny=player.y;
  if(e.key==="ArrowUp") ny--;
  if(e.key==="ArrowDown") ny++;
  if(e.key==="ArrowLeft") nx--;
  if(e.key==="ArrowRight") nx++;
  if(nx>=0 && ny>=0 && nx<size && ny<size && maze[ny][nx]===0) {
    player.x=nx; player.y=ny;
    if(nx===size-1 && ny===size-1) {
      document.getElementById("msg").innerText="🎉 ออกมาได้แล้ว!";
    }
  }
  drawMaze();
});

function init() {
  genMaze();
  player={x:0,y:0};
  drawMaze();
}
init();
