<?php
session_start();
$username = isset($_SESSION['username']) ? $_SESSION['username'] : null;

// ตรวจสอบการออกจากระบบ
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ELDERMIND - MIND TRAINING GAMES</title>
    <style>
        body { 
            font-family: 'Arial', sans-serif; 
            background-color: #f7e8e8; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            height: 100vh; 
            margin: 0; 
            flex-direction: column; 
            text-align: center; 
        }
        .header { 
            width: 100%; 
            position: fixed; 
            top: 0; 
            right: 0; 
            padding: 20px; 
            box-sizing: border-box; 
            display: flex; 
            justify-content: flex-end; 
        }
        .login-button, .logout-button, .username-display { 
            padding: 10px 20px; 
            font-size: 1em; 
            font-weight: bold; 
            color: #ffffff; 
            background-color: #335964; 
            border: none; 
            border-radius: 5px; 
            cursor: pointer; 
            text-decoration: none; 
            transition: background-color 0.3s ease; 
            margin-left: 10px;
        }
        .login-button:hover, .logout-button:hover { background-color: #2a4751; }
        .title-container { margin-bottom: 30px; }
        .main-title { 
            font-family: 'Georgia', serif; 
            font-size: 8em; 
            font-weight: bold; 
            color: #d14949; 
            text-shadow: -3px -3px 0 #335964, 3px -3px 0 #335964, -3px 3px 0 #335964, 3px 3px 0 #335964; 
            line-height: 1; 
        }
        .subtitle { 
            font-family: 'Arial', sans-serif; 
            font-size: 1.5em; 
            color: #335964; 
            letter-spacing: 2px; 
            margin-top: 10px; 
        }
        .start-button { 
            padding: 15px 40px; 
            font-size: 1.5em; 
            font-weight: bold; 
            color: #335964; 
            background-color: transparent; 
            border: 2px solid #335964; 
            border-radius: 50px; 
            cursor: pointer; 
            transition: all 0.3s ease; 
            text-decoration: none; 
        }
        .start-button:hover { background-color: #335964; color: white; }
        .start-button:active { transform: scale(0.95); }
    </style>
</head>
<body>
    <div class="header">
        <?php if ($username): ?>
            <p>สวัสดี, <a href="profile.php"><?php echo htmlspecialchars($username); ?></a></p>
            <a href="?logout=1" class="logout-button">ออกจากระบบ</a>
        <?php else: ?>
            <a href="login.php" class="login-button">เข้าสู่ระบบ</a>
            <a href="register.php" class="login-button">สร้างบัญชี</a>
        <?php endif; ?>
    </div>

    <div class="title-container">
        <h1 class="main-title">ELDERMIND</h1>
        <p class="subtitle">MIND TRAINING GAMES</p>
    </div>
    <a href="advice.html" class="start-button">เริ่มเกม</a>
</body>
</html>
