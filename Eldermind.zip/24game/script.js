let nums = [];
let wrongCount = 0; // ตัวนับรอบผิด
let timeLeft = 120; // เวลา 2 นาที
let timer;

function randomNumbers() {
  nums = [];
  for (let i = 0; i < 4; i++) nums.push(Math.floor(Math.random() * 9) + 1);
  document.getElementById("numbers").innerText = "เลข: " + nums.join(", ");
  document.getElementById("expr").value = "";
  document.getElementById("result").innerText = "";
  wrongCount = 0;

  // เริ่มจับเวลาใหม่
  clearInterval(timer);
  timeLeft = 120;
  updateTimer();
  timer = setInterval(countdown, 1000);
}

function updateTimer() {
  document.getElementById("timer").innerText = "⏱ เหลือเวลา: " + timeLeft + " วินาที";
}

function countdown() {
  timeLeft--;
  updateTimer();
  if (timeLeft <= 0) {
    clearInterval(timer);
    // หมดเวลา → แพ้ + เฉลย
    let solution = findSolution(nums);
    if (solution) {
      document.getElementById("result").innerText =
        "⏳ หมดเวลา! คำตอบที่ถูกต้อง: " + solution;
    } else {
      document.getElementById("result").innerText =
        "⏳ หมดเวลา! ไม่มีวิธีทำให้ได้ 24";
    }
    startNewGameAfterDelay();
  }
}

function check() {
  try {
    let expr = document.getElementById("expr").value;
    let val = eval(expr);

    if (Math.abs(val - 24) < 1e-6) {
      document.getElementById("result").innerText = "🎉 ถูกต้อง!";
      clearInterval(timer);
      startNewGameAfterDelay();
      wrongCount = 0;
    } else {
      wrongCount++;
      if (wrongCount >= 5) {
        clearInterval(timer);
        // ผิดครบ 5 รอบ → รีเซ็ต และโชว์เฉลยจริง
        let solution = findSolution(nums);
        if (solution) {
          document.getElementById("result").innerText =
            "❌ ผิดครบ 5 รอบ! วิธีคิดที่ถูกต้อง: " + solution;
        } else {
          document.getElementById("result").innerText =
            "❌ ผิดครบ 5 รอบ! ไม่มีวิธีทำให้ได้ 24";
        }
        wrongCount = 0;
        startNewGameAfterDelay();
      } else {
        document.getElementById("result").innerText =
          "❌ ได้ค่า = " + val + " (ผิด " + wrongCount + "/5)";
      }
    }
  } catch {
    document.getElementById("result").innerText = "รูปแบบสมการไม่ถูกต้อง";
  }
}

function startNewGameAfterDelay() {
  let delay = 5;
  let msg = setInterval(() => {
    document.getElementById("timer").innerText =
      "🔄 เริ่มเกมใหม่ใน " + delay + " วินาที...";
    delay--;
    if (delay < 0) {
      clearInterval(msg);
      randomNumbers();
    }
  }, 1000);
}

function findSolution(numbers) {
  const ops = ["+", "-", "*", "/"];

  function helper(nums, exprs) {
    if (nums.length === 1) {
      if (Math.abs(nums[0] - 24) < 1e-6) {
        return exprs[0];
      }
      return null;
    }

    for (let i = 0; i < nums.length; i++) {
      for (let j = 0; j < nums.length; j++) {
        if (i !== j) {
          let newNums = [];
          let newExprs = [];
          for (let k = 0; k < nums.length; k++) {
            if (k !== i && k !== j) {
              newNums.push(nums[k]);
              newExprs.push(exprs[k]);
            }
          }

          for (let op of ops) {
            let val;
            if (op === "+") val = nums[i] + nums[j];
            if (op === "-") val = nums[i] - nums[j];
            if (op === "*") val = nums[i] * nums[j];
            if (op === "/") {
              if (nums[j] === 0) continue;
              val = nums[i] / nums[j];
            }

            let exp = "(" + exprs[i] + op + exprs[j] + ")";
            let res = helper([...newNums, val], [...newExprs, exp]);
            if (res) return res;
          }
        }
      }
    }
    return null;
  }

  let exprs = numbers.map(n => n.toString());
  return helper(numbers, exprs);
}

randomNumbers();
