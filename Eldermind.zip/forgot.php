<?php
// forgot.php
// ปรับค่าต่อไปนี้ ให้ตรงกับของคุณ
$host = "localhost";
$dbname = "eldermindg_test";
$user = "eldermindg_test";
$pass = "View2546";
$site_url = "https://www.eldermindgames.lnw.mn"; // เปลี่ยนเป็นโดเมนของคุณ
$from_email = "no-reply@eldermindgames.lnw.mn"; // ปรับถ้าจำเป็น

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $dbuser, $dbpass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e){
    die("เชื่อมต่อ DB ไม่ได้: " . $e->getMessage());
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = trim($_POST['identifier']); // อาจเป็นอีเมลหรือชื่อผู้ใช้

    if (!$identifier) {
        $message = "กรุณากรอกอีเมลหรือชื่อผู้ใช้";
    } else {
        // หา user ตาม email หรือ username
        $stmt = $pdo->prepare("SELECT id, email FROM users WHERE email = ? OR username = ?");
        $stmt->execute([$identifier, $identifier]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$user) {
            // ไม่ระบุว่ามีหรือไม่มี เพื่อความปลอดภัย
            $message = "ถ้ามีบัญชีที่กรอก ระบบจะส่งอีเมลรีเซ็ตรหัสผ่านให้";
        } else {
            // สร้าง token
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', time() + 3600); // หมดอายุ 1 ชั่วโมง

            // เก็บ token ลง DB
            $insert = $pdo->prepare("INSERT INTO password_reset_tokens (user_id, token, expires_at) VALUES (?, ?, ?)");
            $insert->execute([$user['id'], $token, $expires]);

            // สร้างลิงก์รีเซ็ต
            $reset_link = $site_url . "/reset_password.php?token=" . $token;

            // ส่งอีเมล (วิธีง่ายๆ ด้วย mail(); สำหรับ production แนะนำใช้ PHPMailer/SMTP)
            $subject = "รีเซ็ตรหัสผ่าน - ELDERMIND";
            $body = "สวัสดีค่ะ,\n\nพบคำขอรีเซ็ตรหัสผ่านสำหรับบัญชีของคุณ\nกรุณาคลิกหรือนำลิงก์นี้ไปวางในเบราว์เซอร์เพื่อรีเซ็ตรหัสผ่าน (ใช้ได้ 1 ชั่วโมง):\n\n$reset_link\n\nถ้าคุณไม่ได้ร้องขอ ให้เพิกเฉยอีเมลนี้\n\nขอบคุณ,\nทีม ELDERMIND";

            $headers = "From: $from_email\r\n";
            $headers .= "Reply-To: $from_email\r\n";
            // หาก server ของคุณไม่ส่งอีเมลด้วย mail() ให้ใช้ PHPMailer กับ SMTP ของ host

            // ส่งอีเมล (อาจล้มเหลวบนบางโฮสต์ที่ไม่เปิด mail())
            @mail($user['email'], $subject, $body, $headers);

            $message = "ถ้ามีบัญชีที่กรอก ระบบจะส่งอีเมลรีเซ็ตรหัสผ่านให้ (เช็คกล่องจดหมายและจดหมายขยะ)";
            // สำหรับการทดสอบ: คุณอาจแสดง $reset_link ชั่วคราว แต่อย่าแสดงใน production
            // $message .= "<br>DEBUG LINK: $reset_link";
        }
    }
}
?>
<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8">
<title>ลืมรหัสผ่าน - ELDERMIND</title>
<style>
body{font-family:Arial;background:#f7e8e8;display:flex;justify-content:center;align-items:center;height:100vh;margin:0}
.box{background:#fff;padding:30px;border-radius:10px;box-shadow:0 4px 12px rgba(0,0,0,.08);width:360px;text-align:left}
h2{color:#d14949;font-family:Georgia;margin-top:0;text-align:center}
input[type=text]{width:100%;padding:10px;border:2px solid #335964;border-radius:6px}
button{width:100%;padding:12px;background:#335964;color:#fff;border:none;border-radius:6px;cursor:pointer}
.message{margin:12px 0;color:#335964;font-weight:600}
.note{color:#d14949;font-weight:600}
</style>
</head>
<body>
<div class="box">
    <h2>ลืมรหัสผ่าน</h2>
    <p>กรอกอีเมลหรือชื่อผู้ใช้เพื่อรับลิงก์รีเซ็ตรหัสผ่าน</p>

    <?php if($message): ?>
        <div class="message"><?php echo $message; ?></div>
    <?php endif; ?>

    <form method="post" action="">
        <input type="text" name="identifier" placeholder="อีเมลหรือชื่อผู้ใช้" required>
        <div style="height:12px"></div>
        <button type="submit">ส่งลิงก์รีเซ็ต</button>
    </form>

    <p class="note">หมายเหตุ: ลิงก์จะหมดอายุภายใน 1 ชั่วโมง</p>
    <p style="text-align:center"><a href="login.php">กลับไปเข้าสู่ระบบ</a></p>
</div>
</body>
</html>
