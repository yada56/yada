<?php
session_start();

$host = "localhost";
$dbname = "eldermindg_test";
$user = "eldermindg_test";
$pass = "View2546";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e){
    die("เชื่อมต่อ Database ไม่ได้: " . $e->getMessage());
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username=? AND password_plain=?");
    $stmt->execute([$username, $password]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $_SESSION['username'] = $user['username'];
        header("Location: index.php"); // หน้าแรกหลัง login
        exit;
    } else {
        $error = "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง";
    }
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ELDERMIND - เข้าสู่ระบบ</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f7e8e8;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            color: #335964;
        }
        .login-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 350px;
        }
        .main-title {
            font-family: 'Georgia', serif;
            font-size: 2.5em;
            font-weight: bold;
            color: #d14949;
            text-shadow: 
                -1px -1px 0 #335964,  
                1px -1px 0 #335964,
                -1px 1px 0 #335964,
                1px 1px 0 #335964;
            margin-bottom: 20px;
        }
        .input-group {
            margin-bottom: 20px;
            text-align: left;
        }
        .input-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
        }
        .input-group input {
            width: 100%;
            padding: 10px;
            border: 2px solid #335964;
            border-radius: 5px;
            box-sizing: border-box;
            transition: border-color 0.3s;
        }
        .input-group input:focus {
            border-color: #d14949;
            outline: none;
        }
        .login-button {
            width: 100%;
            padding: 12px;
            font-size: 1.1em;
            font-weight: bold;
            color: white;
            background-color: #335964;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .login-button:hover {
            background-color: #2a4751;
        }
        #login-error {
            color: #d14949;
            margin-top: 15px;
            display: <?php echo $error ? 'block' : 'none'; ?>;
            font-weight: 600;
        }
        .additional-links {
            margin-top: 20px;
        }
        .additional-links a {
            color: #335964;
            text-decoration: none;
            font-size: 0.9em;
            margin: 0 10px;
            transition: color 0.3s;
        }
        .additional-links a:hover {
            color: #d14949;
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="login-container">
    <h1 class="main-title">ELDERMIND</h1>
    <p>เข้าสู่ระบบเพื่อเข้าใช้งาน</p>
    <p id="login-error"><?php echo $error; ?></p>
    <form method="post" action="">
        <div class="input-group">
            <label for="username">ชื่อผู้ใช้</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div class="input-group">
            <label for="password">รหัสผ่าน</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit" class="login-button">เข้าสู่ระบบ</button>
    </form>
    <div class="additional-links">
        <a href="forgot.php">ลืมรหัสผ่าน?</a>
        <a href="register.php">สร้างบัญชี</a>
    </div>
</div>

</body>
</html>
